const config = {
    host:'http://localhost:5000',
    getAllVehicles:{
        url:'/api/v1/vehicle/allVehicles'
    }
}

export default config;